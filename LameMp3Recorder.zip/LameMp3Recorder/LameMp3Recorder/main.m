//
//  main.m
//  LameMp3Recorder
//
//  Created by jian zhang on 12-7-13.
//  Copyright (c) 2012年 txtws.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LameMp3RecorderAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LameMp3RecorderAppDelegate class]));
    }
}
