//
//  LameMp3RecorderAppDelegate.h
//  LameMp3Recorder
//
//  Created by jian zhang on 12-7-13.
//  Copyright (c) 2012年 txtws.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LameMp3RecorderViewController;

@interface LameMp3RecorderAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) LameMp3RecorderViewController *viewController;

@end
